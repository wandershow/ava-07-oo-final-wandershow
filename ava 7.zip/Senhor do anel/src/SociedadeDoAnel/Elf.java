package SociedadeDoAnel;

public class Elf extends Person {

	Elf(String name) {
		super(name);
	}

	@Override
	public String raca() {
		// TODO Auto-generated method stub
		return "Elf";
	}

}
