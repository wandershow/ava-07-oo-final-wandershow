package SociedadeDoAnel;

public class Member {

	private Person member;

	public Member(Person person, Fellowship fellowship) {

		this.member = person;
		this.member.setFellowship(fellowship);

	}

	public Person person() {
		return this.member;
	}

	public String getRaca() {
		return this.member.raca();
	}

}
