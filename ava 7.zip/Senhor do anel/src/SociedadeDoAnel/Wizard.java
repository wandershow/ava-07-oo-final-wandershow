package SociedadeDoAnel;

public class Wizard extends Person {

	Wizard(String name) {
		super(name);
	}

	@Override
	public String raca() {
		// TODO Auto-generated method stub
		return "Wizard";
	}
}
