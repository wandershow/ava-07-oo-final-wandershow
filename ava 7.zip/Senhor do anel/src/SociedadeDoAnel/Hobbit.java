package SociedadeDoAnel;

public class Hobbit extends Person {

	Hobbit(String name) {
		super(name);
	}

	@Override
	public String raca() {
		// TODO Auto-generated method stub
		return "Hobbit";
	}

}
