package SociedadeDoAnel;

public class Dwarf extends Person {

	Dwarf(String name) {
		super(name);
	}

	@Override
	public String raca() {
		// TODO Auto-generated method stub
		return "Dwarf";
	}
}
