package SociedadeDoAnel;

public class Human extends Person {

	Human(String name) {
		super(name);
	}

	@Override
	public String raca() {

		return "Human";
	}

}
