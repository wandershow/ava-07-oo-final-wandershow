package SociedadeDoAnel;

public abstract class Person {

	private String name;
	private Fellowship fellowship;
	private boolean isVivo = true;

	public Fellowship fellowship() {

		return this.fellowship;
	}

	public Person(String name) {
		this.name = name;
	}

	public String name() {

		return this.name;
	}

	@Override
	public String toString() {
		return name();
	}

	public void setFellowship(Fellowship fellowship) {
		this.fellowship = fellowship;

	}

	public boolean equals(Person person) {
		return this.name == person.toString();
	}

	public boolean isMemberOfAFellowship() {
		if (fellowship() != null)
			return true;
		return false;
	}

	public boolean isMemberOfTheFellowship(Fellowship fellowship) {
		if (this.fellowship() == (fellowship))
			return true;
		return false;
	}

	public void join(Fellowship fellowship) {
		if (isVivo == false)
			return;
		fellowship.signUp(this);

	}

	public void left() {
		this.fellowship().cancel(this);
		this.setFellowship(null);
	}

	public void die() {
		this.left();
		this.isVivo = false;
	}

	public boolean isFellowOf(Person person) {
		if (this.fellowship() == person.fellowship())
			return true;
		return false;
	}

	public void fellow(Person person) {
		this.setFellowship(person.fellowship());
	}

	public abstract String raca();

}
